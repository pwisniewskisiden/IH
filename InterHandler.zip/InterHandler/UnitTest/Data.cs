﻿using DAL.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest
{
    class Data
    {
        [TestClass]
        public class DataTEST
        {
            /*
            [TestMethod]
            public void BLOpenPurchaseOrdersFileName()
            {
                Assert.AreEqual(36, BLOpenPurchaseOrders.FileName().Length);
            }

            [TestMethod]
            public void BLDealerPartsMasterOrdersFileName()
            {
                Assert.AreEqual(39, BLDealerPartsMaster.FileName().Length);
            }

            [TestMethod]
            public void BLTransactionalDemandFileName()
            {
                Assert.AreEqual(45, BLTransactionalDemand.FileName().Length);
            }
            */

        }
    }
}
